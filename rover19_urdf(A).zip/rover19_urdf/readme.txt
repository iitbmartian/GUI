The gazebo world is just a heightmap of a .png greyscale image.
to run it in other computer add landscape.png in heightmap folder to /usr/share
/gazebo-7/media/materials/teture/. 
other wise the run will give segmentation fault
Launch file for Gaezebo gazebo1.launch
launch for rviz display.launch
